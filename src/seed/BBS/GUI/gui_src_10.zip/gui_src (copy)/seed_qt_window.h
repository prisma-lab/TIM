/*
 * File:   seed_header.h
 * Author: hargalaten
 *
 * Created on 12 dicembre 2012, 15.45
 */

#ifndef SEED_QT_WINDOW_H
#define	SEED_QT_WINDOW_H

#include "../../../seed.h"

#include <QPushButton>
#include <QApplication>



class QPushButton;

class Window : public QWidget {

    Q_OBJECT
public:
    explicit Window(QWidget *parent = 0) :
    QWidget(parent) {
        // Set size of the window
        setFixedSize(100, 50);

        // Create and position the button
        m_button = new QPushButton("Hello World", this);
        m_button->setGeometry(10, 10, 80, 30);
        m_button->setCheckable(true);

        // Set the counter to 0
        m_counter = 0;

        connect(m_button, SIGNAL(clicked(bool)), this, SLOT(slotButtonClicked(bool)));
        connect(this, SIGNAL(counterReached()), QApplication::instance(), SLOT(quit()));
    }

signals:
    void counterReached();
private slots:

    void slotButtonClicked(bool checked) {
        if (checked) {
            m_button->setText("Checked");
        } else {
            m_button->setText("Hello World");
        }

        m_counter++;
        if (m_counter == 10) {
            emit counterReached();
        }
    }
private:
    int m_counter;
    QPushButton *m_button;
};


#endif	/* SEED_QT_WINDOW_H */

