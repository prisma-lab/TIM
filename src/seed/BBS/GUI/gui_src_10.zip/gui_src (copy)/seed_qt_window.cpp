/*
 * File:   main.cpp
 * Author: hargalaten
 *
 * Created on 4 dicembre 2012, 13.59
 */

#include "LTM_eclipseclp.h"



namespace seed {
    
LongTermMemory_eclipseclp::LongTermMemory_eclipseclp(int &argc, char **argv){
    
    eclpse_path = seed::SEED_HOME_PATH + "/eclipseclp";;
    
    ec_set_option_ptr(EC_OPTION_ECLIPSEDIR, (void *) eclpse_path.c_str());
    
    ec_init();
}

bool LongTermMemory_eclipseclp::close(){
    ec_cleanup();
    
    return true;
}
    
bool LongTermMemory_eclipseclp::loadLTM(std::string path){
    
    ltm_path = path;

    //read long time memory
    std::string ltm_path_goal = "[\'" + ltm_path + "\']";

    ec_post_string(ltm_path_goal.c_str());
    EC_resume();
    
    return true; //cant fail?
}

bool LongTermMemory_eclipseclp::loadNodeSemantics(WM_node *new_node){
    
    std::string goalString;
    EC_ref semanticFromEclipse, goalFromEclipse;
    EC_ref schemaInstance;
    EC_word goal, goalList;
    
    //ask to ECLIPSE the semantics of the node
    goalString = "getSemantics(" + new_node->instance + ")";
    post_goal(goalString.c_str());
    EC_resume();

    //if the answer is a semantic definition for that node
    if (EC_resume(EC_atom("ok"), semanticFromEclipse) == EC_yield) {
        //get the first result from ECLIPSE
        semanticFromEclipse.cut_to();
        //load the result into the node
        if (EC_word(semanticFromEclipse).is_nil()) {
            loadSemantics(EC_word(semanticFromEclipse), new_node);
        }
        //resume ECLIPSE
        EC_resume();

        //ask to ECLIPSE the goal of the node
        goalString = "getGoal(" + (new_node->instance) + ")";
        post_goal(goalString.c_str());
        EC_resume();

        //if the goal exists
        if (EC_resume(EC_atom("ok"), goalFromEclipse) == EC_yield) {
            //the node is teleologic
            new_node->teleological = true;
            goalList = EC_word(goalFromEclipse);
            //get the elements of the goal one by one
            while (goalList.is_nil()) {
                goalList.is_list(goal, goalList);
                //bush the element into the goal-list
                new_node->goal.push_back(functor2string(goal));
            }
        } 
        else
            new_node->teleological = false;

        //resume ECLIPSE
        EC_resume();
        
        //the node exists, return true
        return true;
    }
    //oth. return false
    return false;
}
    

//LTM
EC_word LongTermMemory_eclipseclp::writeList(std::vector<std::string> vec){
    EC_word l=nil();

    for(int i=0;i<vec.size();i++){
        char *cstr = new char[vec[i].length() + 1];
        strcpy(cstr, vec[i].c_str());
        l=list(EC_atom(cstr),l);
        delete [] cstr;
    }
    return l;
}

//LTM
std::vector<std::string> LongTermMemory_eclipseclp::readList(EC_word list){
    char *buf;
    std::vector<std::string> app;
    EC_word head,tail;
    if(list.is_nil()){
        list.is_list(head,tail);
        head.is_string(&buf);
        //std::cout<<"read: "<<buf<<"\n";
        app=readList(tail);
        app.push_back(std::string(buf));
    }
    return app;
}

//LTM
void LongTermMemory_eclipseclp::printList(EC_word list)
{
    char *buf;
    EC_word head,tail;

    list.is_list(head,tail);
    head.is_string(&buf);
    if(tail.is_nil())
    {
        printf(" %s", buf);
        printList(tail);
    }
    else printf(" %s\n", buf);
}

//LTM
void LongTermMemory_eclipseclp::printSchemaList(EC_word list)
{
    double d;
    EC_word head,tail,name,abstract,rtm,releaserList,s_tail,releaser;


    list.is_list(head,tail);

    head.is_list(name,s_tail);
    s_tail.is_list(abstract,s_tail);
    s_tail.is_list(rtm,s_tail);
    s_tail.is_list(releaserList,s_tail);



    std::cout<<"        name: "<<functor2string(name)<<"\n";
    abstract.is_double(&d);
    std::cout<<"        abstract: "<<d<<"\n";
    rtm.is_double(&d);
    std::cout<<"        rhythm: "<<d<<"\n";
    std::cout<<"        releaser: ";
    while(releaserList.is_nil())
    {
        releaserList.is_list(releaser,releaserList);
        //releaser.is_string(&buf);

        std::cout<<functor2string(releaser)<<" ";
    }
    std::cout<<"\n\n";
    if(tail.is_nil())
        printSchemaList(tail);


}

//LTM
//trasforma in stringa un generico funtore restituito da ECLIPSE
std::string LongTermMemory_eclipseclp::functor2string(EC_word f){
    char* buf;
    char* subbuf;
    char* st;
    long stl;
    std::string result,subresult;
    std::stringstream ss;
    EC_word arg, parHead,parTail;
    EC_functor fun,subfun;
    EC_atom atm;
    double d;
    int i;

    //se il funtore ha arietà maggiore di zero
    if(f.arity()!=0)
    {
        //estrai in nome del funtore
        f.functor(&fun);
        buf=fun.name();
        result.append(buf);

        //se è un funtore punto (ie. del tipo schema.attributo)
        if(result=="." && f.arity()==2)
        {
            //svuota la stringa
            result="";
            //prendi lo schema
            f.arg(1,arg);
            result.append(functor2string(arg));
            //inseriscilo nella stringa seguito dal punto
            result=result+".";
            //prendi il metodo
            f.arg(2,arg);
            result.append(functor2string(arg));
        }

        else if(result=="-" && f.arity()==1){
            //prendi il parametro ed aggiungilo alla stringa
            f.arg(1,arg);
            //arg.is_string(&buf);
            result.append(functor2string(arg));
        }
        //altrimenti è uno schema avente parametri (eg. goto(X))
        else
        {
            //std::cout<<"funtore: "<<result<<"\n";
            //aggiungi una parentesi aperta
            result.append("(");
            //per ogni argomento
            for(i=1;i<=f.arity();i++)
            {
                //inserisci l'argomento nella stringa
                f.arg(i,arg);
                //std::cout<<"isFun: "<<arg.functor(&subfun) << " isList:"<<!arg.is_list(parHead, parTail)<<"\n";
                //se l'i-esimo argomento è una lista ...e non è un funtore!!
                //  (il punto è sia funtore che lista -.-" quindi per scartarlo va controllato)
                if (arg.functor(&subfun) && !arg.is_list(parHead, parTail)) {
                    //mantieni la sintasi di lista
                    result.append("[");
                    result.append(functor2string(parHead));
                    //std::cout<<"head: "<<functor2string(parHead)<<"\n";
                    while (parTail.is_nil()) {
                        result.append(",");
                        parTail.is_list(parHead, parTail);
                        result.append(functor2string(parHead));
                        //std::cout<<"newhead: "<<functor2string(parHead)<<"\n";
                    }
                    result.append("],");
                    //std::cout << "list: " << result << "\n";
                }
                //altrimenti è un funtore
                else
                    result=result+functor2string(arg)+",";

                //sleep(0.1);
                //std::cout<<result<<"\n";
            }
            result.replace(result.size()-1,1,")");

            //std::cout<<"end functor: "<<result<<"\n";
        }
    }
    //altrimenti non ha argomenti
    else
    {
        //se è un atomo
        if(!f.is_atom(&atm)){
//            std::cout<<"è atomo: "<<atm.name()<<"\n";
            result.append(atm.name());
        }
        //altrimenti, se è una stringa
        else if(!f.is_string(&buf)){
//            std::cout<<"è stringa: "<<buf<<"\n";
            std::string element(buf);

            //se la stringa è un TRUE o FALSE aggiungilo
            if(element=="TRUE" || element=="FALSE")
                result.append(element);
            //altrimenti aggiungi gli apici
            else
                result.append("\""+element+"\"");

        }
//        else if(f.is_string(&buf)){
//            std::cout<<"dentro\n";
//            result.append(buf);
//            result="\""+result+"\"";
//        }
        else if(!f.is_double(&d)){
            ss<<d;
            result.append(ss.str());
        }
    }
    //restituisci al stringa
    return result;
}

/**
 *
 * @param FromEclipse
 * @param expNode
 * carica la definizione semantica restituita da ECLIPSE (FromEclipse)
 * istanziando i figli del nodo da espandere (expNode)
 */
void LongTermMemory_eclipseclp::loadSemantics(EC_word FromEclipse,WM_node* expNode){
    double d;
    WM_node *newSon;
    EC_word head,tail,name,rtm,releaserList,s_tail,releaser;


    //estrai un sottoschema dalla lista di ECLIPSE
    FromEclipse.is_list(head,tail);
    //estrai gli elementi del sottoschema
    head.is_list(name,s_tail);
    //s_tail.is_list(abstract,s_tail);
    s_tail.is_list(rtm,s_tail);
    s_tail.is_list(releaserList,s_tail);

    //aggiungi il nuovo nodo
//    if(name.is_string(s))
//        newSon=expNode->addSon("\""+functor2string(name)+"\"");
//    else


//    std::cout<<"loading "<<functor2string(name)<<"\n";
    newSon=expNode->addSon(functor2string(name));

    //std::cout<<"son added!\n";

    //std::cout<<"LOADING: "<<newSon->instance<<"\n";

    rtm.is_double(&d);
    //eredito l'amplificazione di mio padre
    //newSon->amplification=expNode->amplification;
    //newSon->contribution = expNode->contribution;

    newSon->background = expNode->background;
    //la magnitudine è il massimo tra la mia e quella di mio padre
//    if(expNode->magnitude>d)
//        newSon->magnitude=expNode->magnitude;
//    else
//        newSon->magnitude=d;
    //*(newSon->contribution["LTM"])=d;
    //newSon->amplify("LTM",d);

    //estrai i vari e;lementi del releaser
    while(releaserList.is_nil())
    {
        releaserList.is_list(releaser,releaserList);
        newSon->releaser.push_back(functor2string(releaser));
    }

    //carica nella WM ulteriori sottoschemi
    if(tail.is_nil())
        loadSemantics(tail, expNode);
}


} //seed namespace

