/* 
 * File:   gui.h
 * Author: hargalaten
 *
 * Created on 23 luglio 2015, 12.58
 */


//#include "../../seed.h"

#include "gui_tree.h"

Node::Node(GraphWidget *graphWidget)
    : graph(graphWidget)
{
    setFlag(ItemIsMovable);
    setFlag(ItemSendsGeometryChanges);
    setCacheMode(DeviceCoordinateCache);
    setZValue(-1);
}

bool Node::releaser2qstring(WM_node *node, QString *qs){
    bool nodeReleased = true;
    std::stringstream ss;
    //for each element of the releaser
    for(int i=0; i<node->releaser.size(); i++){
        //if the element is false plot it as red
        if( (node->releaser[i].at(0) != '-' && WMV.get<double>(node->releaser[i]) != 1) ||
            (node->releaser[i].at(0) == '-' && WMV.get<double>(node->releaser[i]) == 1) ){
            nodeReleased = false;
            //ss<<"<font color=\"red\">"<<node->releaser[i]<<"</font>"; //html not enabled in qtree
            ss<<"~"<<node->releaser[i];
        }
        //otherwise (is true) plot it as green
        else
            //ss<<"<font color=\"green\">"<<node->releaser[i]<<"</font>";
            ss<<node->releaser[i];

        //if there are other elements left, add an end line
        if(i != node->releaser.size()-1)
            ss<<"  &  ";
            //ss<<"\n";
            //ss<<"<br />";
    }

//        //show also the weight as black number between brackets
//        double *w = WMV.get< std::unordered_map<std::string, double*> >(node->name + ".weights")[node->father->name];
//        if(w!=NULL){
//            ss<<"<br /><font color=\"black\">("<<*w<<")</font>";
//        }

    if(node->releaser.size() != 0)
        //item->setText(2, QString::fromStdString( ss.str() ) );
        *qs = QString::fromStdString( ss.str() );
    else
        //item->setText(2, QString( "TRUE" ) );
        *qs = "TRUE";

    return nodeReleased;
}
    
bool Node::goal2qstring(WM_node *node, QString *qs){
    bool nodeGoal = false;
    std::stringstream ss;
    //for each element of the releaser
    for(int i=0; i<node->goal.size(); i++){
        //if the element is false plot it as black
        if( (node->goal[i].at(0) != '-' && WMV.get<double>(node->goal[i]) != 1) ||
            (node->goal[i].at(0) == '-' && WMV.get<double>(node->goal[i]) == 1) ){
            //ss<<"<font color=\"black\">"<<node->releaser[i]<<"</font>"; //html not enabled in qtree
            ss<<"~"<<node->goal[i];
        }
        //otherwise (is true) plot it as blue
        else{
            nodeGoal = true;
            //ss<<"<font color=\"blue\">"<<node->releaser[i]<<"</font>";
            ss<<node->goal[i];
        }

        //if there are other elements left, add an end line
        if(i != node->goal.size()-1)
            ss<<"  ||  ";
            //ss<<"\n";
            //ss<<"<br />";
    }

    if(node->goal.size() != 0)
        //item->setText(3, QString::fromStdString( ss.str() ) );
        *qs = QString::fromStdString( ss.str() );
    else
        //item->setText(3, QString( "N/A" ) );
        *qs = "";

    return nodeGoal;
}


void Node::loadFromWM(WM_node *node){
    
    instance = QString::fromStdString( node->instance );
    
    releaserStatus = releaser2qstring(node,&(this->releaser));
    brenchReleaserStatus = node->isBranchReleased();
    
    goalStatus = goal2qstring(node,&(this->goal));
    
    abstract = node->abstract;
    
    emp = node->emphasis();
    
    px_x_node = GUI_TREE_X_NODE >= instance.length() * GUI_TREE_X_CHAR2PX ? GUI_TREE_X_NODE : instance.length() * GUI_TREE_X_CHAR2PX;
    px_y_node = GUI_TREE_Y_NODE;
    
    max_node_string = releaser.length() >= instance.length() ? releaser : instance;
    max_node_string = max_node_string.length() >= goal.length() ? max_node_string : goal;
    
    px_x_bb = max_node_string.length() * GUI_TREE_X_CHAR2PX >= px_x_node ? max_node_string.length() * GUI_TREE_X_CHAR2PX : px_x_node;
    px_y_bb = GUI_TREE_Y_NODE;
    
    w_father = nanf("");
    
    if(node->father != NULL){
        double *w = WMV.get< std::unordered_map<std::string, double*> >(node->name + ".weights")[node->father->name];
        if(w != NULL)
            w_father = *w;
    }
    
}

void Node::addSon(QGraphicsScene *scene, Node *new_son){
    son.push_back(new_son);
    
    scene->addItem(new_son);
            
    Edge *e = new Edge(this, new_son);
    scene->addItem(e);
}

//not working
void Node::removeSon(QGraphicsScene *scene, Node *old_son){
    int idx = -1;
    for(auto i=0; i<son.size(); i++){
        if(son[i] == old_son)
            idx = i;
    }
    
    if(idx >= 0){
        son.erase(son.begin()+idx);
        
        Edge *old_edge;
        
        for(auto i=0; i<edges().size(); i++){
            if(edges()[i]->destNode() == old_son){
                old_edge = edges()[i];
                edges().remove(i);
                break;
            }
        }
        
        scene->removeItem(old_son);
        scene->removeItem(old_edge);
        delete old_edge;
        delete old_son;
    }
}


void Node::addEdge(Edge *edge)
{
    edgeList << edge;
    edge->adjust();
}

QVector<Edge *> Node::edges() const
{
    return edgeList;
}



void Node::calculateForces()
{
    if (!scene() || scene()->mouseGrabberItem() == this) {
        newPos = pos();
        return;
    }
    
    // Sum up all forces pushing this item away
    qreal xvel = 0;
    qreal yvel = 0;
//    const QList<QGraphicsItem *> items = scene()->items();
//    for (QGraphicsItem *item : items) {
//        Node *node = qgraphicsitem_cast<Node *>(item);
//        if (!node)
//            continue;
//
//        QPointF vec = mapToItem(node, 0, 0);
//        qreal dx = vec.x();
//        qreal dy = vec.y();
//        double l = 2.0 * (dx * dx + dy * dy);
//        if (l > 0) {
//            xvel += (dx * 150.0) / l;
//            yvel += (dy * 150.0) / l;
//        }
//    }
//    
//    // Now subtract all forces pulling items together
//    double weight = (edgeList.size() + 1) * 10;
//    for (const Edge *edge : qAsConst(edgeList)) {
//        QPointF vec;
//        if (edge->sourceNode() == this)
//            vec = mapToItem(edge->destNode(), 0, 0);
//        else
//            vec = mapToItem(edge->sourceNode(), 0, 0);
//        xvel -= vec.x() / weight;
//        yvel -= vec.y() / weight;
//    }
//    
//    if (qAbs(xvel) < 0.1 && qAbs(yvel) < 0.1)
//        xvel = yvel = 0;
    
    QRectF sceneRect = scene()->sceneRect();
    newPos = pos() + QPointF(xvel, yvel);
    newPos.setX(qMin(qMax(newPos.x(), sceneRect.left() + px_x_node/2), sceneRect.right() - px_x_node/2));
    newPos.setY(qMin(qMax(newPos.y(), sceneRect.top() + px_y_node/2), sceneRect.bottom() - px_y_node/2));
}


bool Node::advancePosition()
{
    if (newPos == pos())
        return false;

    setPos(newPos);
    return true;
}

QRectF Node::boundingRect() const
{
    qreal adjust = 10;//2;
    //initial point (left-down) and lengths
    return QRectF( -px_x_bb/2 - adjust, -px_y_bb/2 - adjust, px_x_bb + 5 + adjust, px_y_bb + 10 + adjust);
}

void Node::paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *)
{
    QFontMetrics fm = painter->fontMetrics(); //get dimensions of charts with the current font
    int txt_y_px = fm.height() + 2;
    
    
    //std::cout<<"max string: "<<max_node_string.toStdString()<<std::endl;
    
    //std::cout<<instance.toStdString()<<" bb len: "<<px_x_bb<<std::endl;
    
    //painter->setPen(Qt::NoPen);
    
    if(goalStatus)
        painter->setPen(QPen(Qt::blue, 5));
    else if(brenchReleaserStatus)
        painter->setPen(QPen(Qt::green, 5));
    else
        painter->setPen(QPen(Qt::red, 5));
    //painter->setPen(QPen(Qt::black, 0));
    
    if(abstract)
        painter->setBrush(Qt::lightGray);
    else
        painter->setBrush(Qt::darkGray);
    
    //initial point (left-down) and lengths
    painter->drawEllipse(-px_x_node/2, -px_y_node/2, px_x_node, px_y_node);

//    QRadialGradient gradient(-3, -3, GUI_TREE_X_NODE/2);
//    if (option->state & QStyle::State_Sunken) {
//        gradient.setCenter(3, 3);
//        gradient.setFocalPoint(3, 3);
//        gradient.setColorAt(1, QColor(Qt::gray).lighter(120));
//        gradient.setColorAt(0, QColor(Qt::darkGray).lighter(120));
//    } else {
//        gradient.setColorAt(0, Qt::gray);
//        gradient.setColorAt(1, Qt::darkGray);
//    }
//    painter->setBrush(gradient);
//
//    painter->setPen(QPen(Qt::black, 0));
//    painter->drawEllipse(-GUI_TREE_X_NODE/2, -GUI_TREE_Y_NODE/2, GUI_TREE_X_NODE, GUI_TREE_Y_NODE);
    
    //text
    painter->setPen(QPen(Qt::black, 0));
    //painter->drawText(boundingRect(), Qt::AlignCenter, instance);
    
    std::stringstream ss;
    ss<<instance.toStdString() << "\n(" << emp << ")";
    painter->drawText(boundingRect(), Qt::AlignCenter, QString::fromStdString( ss.str() ));
    
    
    //draw releaser
    int rel_x_px = fm.width(releaser) + 4;
    
    if(releaserStatus)
        painter->setBrush(Qt::green);
    else
        painter->setBrush(Qt::red);
    
    QRectF rel_rect(-rel_x_px/2, -txt_y_px -txt_y_px -5 , rel_x_px, txt_y_px);
    painter->drawRoundRect(rel_rect, 4,4);
    painter->drawText(rel_rect, Qt::AlignCenter, releaser);
    
    //draw goal
    if(goal != ""){
        int goal_x_px = fm.width(goal) + 4;

        painter->setBrush(Qt::cyan);

        QRectF goal_rect(-goal_x_px/2, +txt_y_px +txt_y_px +5 , goal_x_px, -txt_y_px);
        painter->drawRoundRect(goal_rect, 4,4);
        painter->drawText(goal_rect, Qt::AlignCenter, goal);
    }
}


QVariant Node::itemChange(GraphicsItemChange change, const QVariant &value)
{
    switch (change) {
    case ItemPositionHasChanged:
        for (Edge *edge : qAsConst(edgeList))
            edge->adjust();
        graph->itemMoved();
        break;
    default:
        break;
    };

    return QGraphicsItem::itemChange(change, value);
}

void Node::mousePressEvent(QGraphicsSceneMouseEvent *event)
{
    update();
    QGraphicsItem::mousePressEvent(event);
}

void Node::mouseReleaseEvent(QGraphicsSceneMouseEvent *event)
{
    update();
    QGraphicsItem::mouseReleaseEvent(event);
}





//EDGES:



Edge::Edge(Node *sourceNode, Node *destNode)
    : source(sourceNode), dest(destNode)
{
    setAcceptedMouseButtons(Qt::NoButton);
    source->addEdge(this);
    dest->addEdge(this);
    adjust();
}

Node *Edge::sourceNode() const
{
    return source;
}

Node *Edge::destNode() const
{
    return dest;
}


void Edge::adjust()
{
    if (!source || !dest)
        return;

    QLineF line(mapFromItem(source, 0, 0), mapFromItem(dest, 0, 0));
    qreal length = line.length();

    prepareGeometryChange();

    if (length > qreal(20.)) {
        QPointF src_edgeOffset((line.dx() * source->px_x_node/2) / length, (line.dy() * source->px_y_node/2) / length);
        QPointF dst_edgeOffset((line.dx() * dest->px_x_node/2) / length, (line.dy() * dest->px_y_node/2) / length);
        
        sourcePoint = line.p1() + src_edgeOffset;
        destPoint = line.p2() - dst_edgeOffset;
    } else {
        sourcePoint = destPoint = line.p1();
    }
}

QRectF Edge::boundingRect() const
{
    if (!source || !dest)
        return QRectF();

    qreal penWidth = 1;
    qreal extra = (penWidth + arrowSize) / 2.0;

    return QRectF(sourcePoint, QSizeF(destPoint.x() - sourcePoint.x(),
                                      destPoint.y() - sourcePoint.y()))
        .normalized()
        .adjusted(-extra, -extra, extra, extra);
}


void Edge::paint(QPainter *painter, const QStyleOptionGraphicsItem *, QWidget *)
{
    if (!source || !dest)
        return;

    QLineF line(sourcePoint, destPoint);
    if (qFuzzyCompare(line.length(), qreal(0.)))
        return;
    
    
    // Draw the line itself
    if(source->goalStatus)
        painter->setPen(QPen(Qt::blue, 2, Qt::SolidLine, Qt::RoundCap, Qt::RoundJoin));
    else if(source->brenchReleaserStatus)
        painter->setPen(QPen(Qt::green, 2, Qt::SolidLine, Qt::RoundCap, Qt::RoundJoin));
    else
        painter->setPen(QPen(Qt::red, 2, Qt::SolidLine, Qt::RoundCap, Qt::RoundJoin));
    //painter->setPen(QPen(Qt::black, 1, Qt::SolidLine, Qt::RoundCap, Qt::RoundJoin));
    painter->drawLine(line);

    
    
    // Draw the arrows
    double angle = std::atan2(-line.dy(), line.dx());

//    QPointF sourceArrowP1 = sourcePoint + QPointF(sin(angle + M_PI / 3) * arrowSize,
//                                                  cos(angle + M_PI / 3) * arrowSize);
//    QPointF sourceArrowP2 = sourcePoint + QPointF(sin(angle + M_PI - M_PI / 3) * arrowSize,
//                                                  cos(angle + M_PI - M_PI / 3) * arrowSize);
    
    QPointF destArrowP1 = destPoint + QPointF(sin(angle - M_PI / 3) * arrowSize,
                                              cos(angle - M_PI / 3) * arrowSize);
    QPointF destArrowP2 = destPoint + QPointF(sin(angle - M_PI + M_PI / 3) * arrowSize,
                                              cos(angle - M_PI + M_PI / 3) * arrowSize);

    if(source->goalStatus)
        painter->setBrush(Qt::blue);
    else if(source->brenchReleaserStatus)
        painter->setBrush(Qt::green);
    else
        painter->setBrush(Qt::red);
    //painter->setBrush(Qt::black);
    
//    painter->drawPolygon(QPolygonF() << line.p1() << sourceArrowP1 << sourceArrowP2);
    painter->drawPolygon(QPolygonF() << line.p2() << destArrowP1 << destArrowP2);
    
    
    //text
    painter->setPen(QPen(Qt::black, 0));
    //painter->drawText(boundingRect(), Qt::AlignCenter, instance);
    
    std::stringstream ss;
    
    //show also the weight as black number between brackets
    
    if(!isnan(dest->w_father)){
        ss<<"("<<dest->w_father<<")";
        painter->drawText(boundingRect(), Qt::AlignCenter, QString::fromStdString( ss.str() ));
    }
}




//WIDGET:



GraphWidget::GraphWidget(QWidget *parent)
    : QGraphicsView(parent)
{
    QGraphicsScene *scene = new QGraphicsScene(this);
    scene->setItemIndexMethod(QGraphicsScene::NoIndex);
    //scene->setSceneRect(-200, -200, 400, 400);
    setScene(scene);
    setCacheMode(CacheBackground);
    setViewportUpdateMode(BoundingRectViewportUpdate);
    setRenderHint(QPainter::Antialiasing);
    setTransformationAnchor(AnchorUnderMouse);
    scale(qreal(0.8), qreal(0.8));
    setMinimumSize(400, 400);
    setWindowTitle(tr("WM tree"));
    
    pthread_mutex_lock(&memMutex);
    
    centerNode = new Node(this);
    centerNode->loadFromWM(WM);
    scene->addItem(centerNode);
    
    std::cout<<"GUI-tree: root loaded"<<std::endl;
    
    loadFromWM(scene,WM,centerNode);
    
    pthread_mutex_unlock(&memMutex);
    
    std::cout<<"GUI-tree: tree loaded"<<std::endl;
    
    //centerNode->setPos(-150,0);
    
    setNodePosition(centerNode, -150, 0);
    
    std::cout<<"GUI-tree: tree pos set"<<std::endl;
    
    setTransformationAnchor(QGraphicsView::NoAnchor);
}


void GraphWidget::loadFromWM(QGraphicsScene *scene, WM_node *node, Node *father_qt)
{
    int total_px_segment = 0;
    
    //for each son node
    for(int i=0; i<node->son.size(); i++){
        //if the node is expanded and, if show-less-mode is enabled, the releaser is true
        if (node->son[i]->expanded ){ //&& ( node->son[i]->releaserStatus() ) ){
            
            //create a new agNode which represents it
            Node *node_qt = new Node(this);
            father_qt->addSon(scene, node_qt);
            node_qt->loadFromWM(node->son[i]);
            

            //recursively plot the subtree
            loadFromWM(scene,node->son[i],node_qt);
            
            total_px_segment += node_qt->px_segment;
        }
    }
    
    if(total_px_segment == 0) //I'm a leaf node
        father_qt->px_segment =  GUI_TREE_Y_STEP; //default px segment needed to visualize a single node
    else
        father_qt->px_segment = total_px_segment;
}

void GraphWidget::removeSubtree(QGraphicsScene *scene, Node *root_qt)
{
    //for each son node
    //for(int i=0; i<root_qt->son.size(); i++){
    while(root_qt->son.size() > 0){
        removeSubtree(scene,root_qt->son[root_qt->son.size()-1]);
        root_qt->removeSon(scene,root_qt->son[root_qt->son.size()-1]);
    }
}

void GraphWidget::setNodePosition(Node *root_qt, int x, int y){
    
    root_qt->setPos(x,y);
    
    int seg_start = y + root_qt->px_segment/2;
    
    //std::cout<<"GUI-tree: setting "<<root_qt->instance.toStdString()<<std::endl;
    
    for(auto i=0; i<root_qt->son.size(); i++){
        Node *son = root_qt->son[i];
        
        int x_pos = x + GUI_TREE_X_STEP;
        int y_pos = seg_start - son->px_segment/2;
        
        //std::cout<<"GUI-tree:\t setting "<<son->instance.toStdString()<< " to "<<x_pos<<", "<<y_pos<<std::endl;
        
        //son->setPos( x_pos, y_pos );
        
        setNodePosition(son, x_pos, y_pos);
        
        seg_start -= son->px_segment;
    }
}

void GraphWidget::updateFromWM(QGraphicsScene *scene, WM_node *wm_node, Node *qt_node){
        
    //update the node
    qt_node->loadFromWM(wm_node);
    qt_node->update();

    //NOTE: wm_tree and qt_tree MUST be ordered in the same way!!!
    for (int i = 0; i < wm_node->son.size(); i++) {

        if( i >= qt_node->son.size() ){
            //the node is new ..add it to the tree

            //std::cout<<"GUI-tree: new node found "<<wm_node->son[i]->instance<<std::endl;
            
            //if the node is expanded and, if show-less-mode is enabled, the releaser is true
            if (wm_node->son[i]->expanded ){ //&& ( wm_node->son[i]->releaserStatus() ) ){
                //create a new agNode which represents it
                Node *new_qt_node = new Node(this);
                qt_node->addSon(scene, new_qt_node);
                new_qt_node->loadFromWM(wm_node->son[i]);
                
                //recursively plot the subtree
                //updateFromWM(scene,wm_node->son[i],new_qt_node);
                loadFromWM(scene,wm_node->son[i],new_qt_node);
                
                qt_node->px_segment += new_qt_node->px_segment;
                //std::cout<<"GUI-tree: expanded! "<<std::endl;
            }
        }
        else{
            
            Node *current_son = qt_node->son[i];
            
//            if( current_son->instance.toStdString() != wm_node->son[i]->instance ){
//                qt_node->px_segment -= current_son->px_segment;
//                scene->removeItem(current_son);
//                scene->removeItem(qt_node->edges()[i]);
//                qt_node->removeSonAndEdge(current_son);
//                i--;
//                continue;
//            }
            
            qt_node->px_segment -= current_son->px_segment;
            
            //update the node
            updateFromWM(scene, wm_node->son[i], current_son);
            
            qt_node->px_segment += current_son->px_segment; //it can be updated
        }
        
    }

    //remove qt_nodes if they are no more in WM
    for (int i = wm_node->son.size(); i < qt_node->son.size(); i++) {
        qt_node->px_segment -= qt_node->son[i]->px_segment;
        
        removeSubtree(scene, qt_node->son[i]);
        qt_node->removeSon(scene,qt_node->son[i]);
    }
}



void GraphWidget::itemMoved()
{
    if (!timerId)
        timerId = startTimer(1000 / 25);
}

void GraphWidget::keyPressEvent(QKeyEvent *event)
{
    switch (event->key()) {
    case Qt::Key_Up:
        centerNode->moveBy(0, -20);
        break;
    case Qt::Key_Down:
        centerNode->moveBy(0, 20);
        break;
    case Qt::Key_Left:
        centerNode->moveBy(-20, 0);
        break;
    case Qt::Key_Right:
        centerNode->moveBy(20, 0);
        break;
//    case Qt::Key_Plus:
//        zoomIn();
//        break;
//    case Qt::Key_Minus:
//        zoomOut();
//        break;
//    case Qt::Key_Space:
//    case Qt::Key_Enter:
//        shuffle();
//        break;
//    default:
//        QGraphicsView::keyPressEvent(event);
    }
}


void GraphWidget::timerEvent(QTimerEvent *event)
{
    Q_UNUSED(event);
    
    //UPDATE:
    pthread_mutex_lock(&memMutex);
    
    if(!dead())
        updateFromWM(scene(), WM, centerNode);
    
    pthread_mutex_unlock(&memMutex);
    
    setNodePosition(centerNode, -150, 0);
     
    scene()->update();
    

//    QVector<Node *> nodes;
//    const QList<QGraphicsItem *> items = scene()->items();
//    for (QGraphicsItem *item : items) {
//        if (Node *node = qgraphicsitem_cast<Node *>(item))
//            nodes << node;
//    }
//
//    for (Node *node : qAsConst(nodes))
//        node->calculateForces();
//
//    bool itemsMoved = false;
//    for (Node *node : qAsConst(nodes)) {
//        if (node->advancePosition())
//            itemsMoved = true;
//    }
//
//    if (!itemsMoved) {
//        killTimer(timerId);
//        timerId = 0;
//    }
}


void GraphWidget::wheelEvent(QWheelEvent *event)
{
    scaleView(pow(2., event->angleDelta().y() / 240.0));
}

void GraphWidget::mousePressEvent(QMouseEvent* event)
{
    if (event->button() == Qt::LeftButton)
    {
        // Store original position.
        m_ori_pos = event->pos(); //mapToScene( event->pos() );
        
        //std::cout<<"start POS: "<<m_ori_pos.x()<<", "<<m_ori_pos.y()<<std::endl;
    }
}

void GraphWidget::mouseMoveEvent(QMouseEvent* event)
{
    if (event->buttons() & Qt::LeftButton)
    {
//        QPointF oldp = mapToScene(m_originX, m_originY);
//        QPointF newp = mapToScene(event->pos());
        
        m_new_pos = event->pos(); //mapToScene( event->pos() );
        
        QPointF translation = m_new_pos - m_ori_pos;

        translate(translation.x(), translation.y());
        //this->horizontalScrollBar()->setValue( this->horizontalScrollBar()->value() + translation.x() );
        //this->verticalScrollBar()->setValue( this->verticalScrollBar()->value() + translation.y() );
        
        //std::cout<<"new POS: "<<m_new_pos.x()<<", "<<m_new_pos.y()<<std::endl;
        //std::cout<<"\ttranslate: "<<-translation.x()<<", "<<-translation.y()<<std::endl;
        
        m_ori_pos = m_new_pos;
    }
}


void GraphWidget::drawBackground(QPainter *painter, const QRectF &rect)
{
    Q_UNUSED(rect);

//    // Shadow
//    QRectF sceneRect = this->sceneRect();
//    QRectF rightShadow(sceneRect.right(), sceneRect.top() + 5, 5, sceneRect.height());
//    QRectF bottomShadow(sceneRect.left() + 5, sceneRect.bottom(), sceneRect.width(), 5);
//    if (rightShadow.intersects(rect) || rightShadow.contains(rect))
//        painter->fillRect(rightShadow, Qt::darkGray);
//    if (bottomShadow.intersects(rect) || bottomShadow.contains(rect))
//        painter->fillRect(bottomShadow, Qt::darkGray);
//
//    // Fill
//    QLinearGradient gradient(sceneRect.topLeft(), sceneRect.bottomRight());
//    gradient.setColorAt(0, Qt::white);
//    gradient.setColorAt(1, Qt::lightGray);
//    painter->fillRect(rect.intersected(sceneRect), gradient);
//    painter->setBrush(Qt::NoBrush);
//    painter->drawRect(sceneRect);
//
//    // Text
//    QRectF textRect(sceneRect.left() + 4, sceneRect.top() + 4,
//                    sceneRect.width() - 4, sceneRect.height() - 4);
//    QString message(tr("Click and drag the nodes around, and zoom with the mouse "
//                       "wheel or the '+' and '-' keys"));
//
//    QFont font = painter->font();
//    font.setBold(true);
//    font.setPointSize(14);
//    painter->setFont(font);
//    painter->setPen(Qt::lightGray);
//    painter->drawText(textRect.translated(2, 2), message);
//    painter->setPen(Qt::black);
//    painter->drawText(textRect, message);
}


void GraphWidget::scaleView(qreal scaleFactor)
{
    qreal factor = transform().scale(scaleFactor, scaleFactor).mapRect(QRectF(0, 0, 1, 1)).width();
    if (factor < 0.07 || factor > 100)
        return;

    scale(scaleFactor, scaleFactor);
}


